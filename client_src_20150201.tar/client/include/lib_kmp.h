/**
 *��Ҫ: �ͻ���(ģʽƥ��)
 *����: 2005/10/01
 *�޸�: 2014/04/08
 *��Ȩ: 2005-2015 chengdehai. all rights reserved.
 */

#ifndef __LIB_KMP_H__
#define __LIB_KMP_H__

#include "lib_log.h"

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/*KMPƥ��*/
int lib_kmp_match(char *text,const char *begin,const char *end,char *buf);

/*KMPƥ��*/
int lib_kmp_special(char       *text,
                    const char *begin,
                    const char *end,
                    const char *match,
                    int        *flag);

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /*__LIB_KMP_H__*/

