/**
 *��Ҫ: �ͻ���(ͨѶ)
 *����: 2005/10/01
 *�޸�: 2014/04/22
 *��Ȩ: 2005-2015 chengdehai. all rights reserved.
 */

#ifndef __LIB_TCP_H__
#define __LIB_TCP_H__

#include "lib_log.h"

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/*���*/
typedef SOCKET lib_tcp_t;

/*��ʼ*/
int lib_tcp_init(void);

/*��ֹ*/
void lib_tcp_exit(void);

/*��*/
int lib_tcp_open(lib_tcp_t **tcp,const char *addr,ushort port,int *occupied);

/*�ر�*/
void lib_tcp_close(lib_tcp_t **tcp);

/*����*/
int lib_tcp_accept(lib_tcp_t **tcp,lib_tcp_t host,char *remote);

/*����*/
int lib_tcp_connect(lib_tcp_t **tcp,const char *addr,ushort port);

/*����*/
int lib_tcp_send(lib_tcp_t tcp,void *packet,int length);

/*����*/
int lib_tcp_recv(lib_tcp_t tcp,void *packet,int length);

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /*__LIB_TCP_H__*/

