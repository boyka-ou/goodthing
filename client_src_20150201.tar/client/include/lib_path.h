/**
 *��Ҫ: �ͻ���(Ŀ¼����)
 *����: 2005/10/01
 *�޸�: 2014/04/22
 *��Ȩ: 2005-2015 chengdehai. all rights reserved.
 */

#ifndef __LIB_PATH_H__
#define __LIB_PATH_H__

#include "lib_tcp.h"
#include "lib_exec.h"

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

/*��������*/
typedef int (*file_func_t)(lib_tcp_t *handle,char *fname,char *code);

/*����Ŀ¼*/
int lib_path_loop(char        *path,
                  char        *type,
                  lib_tcp_t   *tcp,
                  file_func_t func,
                  ulong       *total);

#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /*__LIB_PATH_H__*/

